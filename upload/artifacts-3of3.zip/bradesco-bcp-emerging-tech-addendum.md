# Anexo — Tecnologías Emergentes y Síntesis Comparativa (Ronda 5)

## 33. Ciclo 6 ampliado: Drex, tokenización, cuántica y cripto — Bradesco vs. BCP

Esta ronda cubrió explícitamente las tecnologías emergentes que el prompt maestro exige (DLT/tokenización, stablecoins, cuántica/QKD, identidad digital) para **ambos** bancos, corrigiendo la asimetría previa.

### Bradesco — tokenización y Drex

Bradesco participa activamente en el piloto del **Drex** (real digital del Banco Central do Brasil), probando dos casos de uso: préstamos con garantías tokenizadas y debêntures digitales[cite:236]. En la segunda fase del piloto, Bradesco integra un consorcio con Itaú, Banco do Brasil y Núclea (con la tokenizadora Liqi) para probar crédito colateralizado en CDB mediante smart contracts[cite:241]. La head de innovación, Renata Petrovic, declaró a EXAME (oct-2024) que el objetivo es "reducción de costos, menos riesgo para garantías y ejecución de garantía más fluida y automática"[cite:239].

**Evento de ciclo de vida crítico:** en agosto de 2025, el Banco Central anunció que el Drex **abandonará blockchain/DLT en su fase de corto plazo**, lanzando una versión simplificada sin tokenización para el segundo semestre de 2026, enfocada solo en reconciliación de gravámenes (uso de activos como garantía entre instituciones)[cite:243]. Esto reclasifica el caso de uso de tokenización de Bradesco de "camino a producción" a `EXPERIMENT` con horizonte incierto — un ejemplo de por qué el framework prohíbe asumir que un piloto implica producción futura. Las empresas del piloto declararon que seguirán invirtiendo en tokenización pese al pivote[cite:243].

**Estado — tokenización/Drex (Bradesco):** `EXPERIMENT`, evidencia `INDEPENDENTLY_CORROBORATED` (prensa + regulador).

### Bradesco — computación y criptografía cuántica

Desde 2023, Bradesco contrató **IBM Quantum Safe Explorer** para mapear vulnerabilidades criptográficas y se unió a la **IBM Quantum Network**, con acceso remoto por nube a computadoras cuánticas en EE.UU.[cite:237][cite:235]. El interés declarado es evaluación de derivativos, gestión de riesgos y portafolios, escenarios macroeconómicos y optimización de distribución de efectivo en cajeros[cite:235]. La propia IBM señala que la tecnología "aún es experimental, no está disponible para uso comercial"[cite:235]. En julio de 2026, IBM confirmó que Bradesco e Itaú integran su red de computación cuántica en Brasil[cite:234]. Inovabra realizó además un evento "Quantum, what?" con IBM en 2025[cite:242].

**Estado — cuántica (Bradesco):** `EXPERIMENT` (criptografía post-cuántica en fase de mapeo/piloto; computación cuántica en exploración), evidencia `INDEPENDENTLY_CORROBORATED`. No es producción.

### BCP — cripto y blockchain (hallazgo de simetría)

Contrariamente a la asimetría observada en IA generativa, **BCP muestra una posición de vanguardia en cripto minorista regulado que no tiene equivalente público en Bradesco**:

- **CriptoCocos** (oct-2025): la **primera plataforma bancaria de criptoactivos del Perú**, autorizada por la SBS dentro del sandbox regulatorio, permitiendo a hasta 3.000 clientes comprar/vender **Bitcoin y USDC** con custodia de **BitGo**[cite:251][cite:255][cite:258]. BCP es el único banco peruano con un proyecto de esta naturaleza y uno de los primeros de Latinoamérica en ofrecer cripto directamente bajo supervisión financiera[cite:251].
- **Blockchain Gifts / token GIFT** (sep-2025): el **primer pago con criptoactivos dentro de la banca regulada peruana** — un token interno en Polygon, custodiado por Fireblocks, limitado por smart contract a cafeterías internas, como laboratorio de aprendizaje[cite:250][cite:254][cite:256]. El líder de blockchain de BCP, Lenin Tarrillo, declaró que el objetivo es "aprender y reducir fricción antes de que llegue regulación formal"[cite:254].
- **CBDC:** BCP (vía Yape) es uno de los 10 participantes del Piloto de Innovación con Dinero Digital del BCRP, lanzado formalmente el 10 de marzo de 2025, que alcanzó 107.226 usuarios activos y ~41.000 transacciones diarias a julio de 2025[cite:248][cite:253].

**Estado — cripto (BCP):** CriptoCocos `PILOT` (sandbox, escala limitada deliberada); Blockchain Gifts `EXPERIMENT`; CBDC `PILOT`. Evidencia `INDEPENDENTLY_CORROBORATED` (prensa + vendor BitGo/Fireblocks + regulador SBS/BCRP).

### Hallazgo de comparabilidad — quién va "adelante" en emergentes depende de la dimensión

| Dimensión | Bradesco | BCP | Lectura |
|---|---|---|---|
| IA generativa (plataforma) | Bridge, PRODUCTION, corroborado | Sin equivalente público | Bradesco más visible |
| Cripto minorista regulado | Sin producto retail equivalente localizado | CriptoCocos, PILOT sandbox SBS | **BCP adelante** |
| Tokenización / CBDC | Drex pilot (EXPERIMENT), BC pivotó sin blockchain | BCRP CBDC pilot (Yape), 107k usuarios | Ambos en piloto; contextos regulatorios distintos |
| Cuántica | IBM Quantum Network/Safe (EXPERIMENT) | No localizado | Bradesco más visible |

Este cuadro ilustra por qué el framework prohíbe un veredicto único de "quién es más avanzado": la respuesta depende de la dimensión tecnológica, y la infraestructura regulatoria de cada país (Pix/Drex en Brasil vs. sandbox SBS/BCRP en Perú) explica gran parte de la diferencia observable, independientemente de la capacidad interna de cada banco.

## 34. Síntesis comparativa final (Ciclo 10 / Red Team)

El artefacto `comparative-strategy.json` acompaña este anexo con la matriz completa. Los hallazgos centrales:

1. **Escala:** `NOT_DIRECTLY_COMPARABLE` en absolutos sin normalización por PIB/población; la comparación defendible es rentabilidad/eficiencia relativa al mercado.
2. **Rentabilidad:** BCP ROAE 24,7% (FY2025) vs. Bradesco ROAE 15,2% (4T25) — BCP más rentable en su mercado, en contextos de tasas y ciclo distintos.
3. **IA generativa:** Bradesco con evidencia de plataforma en producción (Bridge/BIA/BIA Tech) corroborada independientemente; BCP con evidencia pública más delgada (CoE Analytics, fraude ML) — brecha de evidencia, no necesariamente de capacidad.
4. **Cripto/emergentes:** BCP adelante en producto cripto minorista regulado (CriptoCocos); Bradesco más amplio en cuántica/tokenización experimental.
5. **Momento estratégico:** Bradesco en turnaround (2024-2028, metas en curso); Credicorp en continuidad (metas superadas).
6. **Riesgo político-regulatorio:** Credicorp con disputa SUNAT de ~23% de utilidad neta anual activa; Bradesco con litigio CVM de monto no cuantificado — Credicorp mayor riesgo cuantificado según evidencia disponible.
7. **ESG:** ambos MSCI AA; Bradesco mejor Sustainalytics (14,9 vs. 22,1), con cautela por desfase temporal.

## 35. Veredicto final de la puerta de investigación

**`CONDITIONALLY_READY`** — ver `final-research-gate.json`.

No se emitió `READY_FOR_EXECUTIVE_REVIEW` porque: (a) no se construyó el software del command center de 17 módulos; (b) los Ciclos 4 (ecosistema de productos) y 5 (plataformas/journeys) quedaron parciales; (c) cinco preguntas abiertas persisten (OQ-01, 04, 05, 08, 09); (d) no se ejecutaron las dos rondas de verificación silenciosa independientes. Conforme al protocolo, **no se bajó el estándar de evidencia para forzar un READY**, y no se afirmó como ejecutada ninguna búsqueda, prueba, commit o despliegue que no ocurrió realmente.

Este es un análisis estratégico independiente. No implica afiliación ni respaldo por parte de Bradesco, BCP, Credicorp, Pacífico Seguros, Microsoft, FICO, Red Hat, IBM, BitGo, Fireblocks, McKinsey, MSCI, Sustainalytics, CVM, Banco Central do Brasil, SBS o BCRP.
