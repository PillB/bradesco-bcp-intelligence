# Atualização Bilíngue — Ronda 7: Evidência, Implementação e Rotas
# Actualización Bilingüe — Ronda 7: Evidencia, Implementación y Rutas

**Programa / Programa:** Bradesco × BCP Strategic Intelligence Command Center  
**Data-base / Fecha de corte:** 10 de agosto de 2026  
**Veredito atual / Veredicto actual:** `CONDITIONALLY_READY`

---

## A. Rebaseline executado / Rebaseline ejecutado

### 🇧🇷 Português (Brasil)

O repositório de referência `PillB/AIMarket-Design-Consulting-Reports` foi revalidado no branch `main`, HEAD `806e6fd5fb4a5f7aea8e84d662fec7761495e09e`. Não existem pull requests abertos. Os commits mais recentes são de agosto de 2026 e tratam de worklog, revisão de conversão, acessibilidade/componentes e instrumentação, não de uma implementação Bradesco × BCP.

**Implicação:** a pesquisa e os artefatos devem permanecer em uma rota independente; nenhuma mutação do repositório de referência deve ser feita sem uma etapa explícita de implementação, branch dedicado, testes RED e aprovação para escrita.

### 🇵🇪 Español (Perú)

El repositorio de referencia `PillB/AIMarket-Design-Consulting-Reports` fue revalidado en la rama `main`, HEAD `806e6fd5fb4a5f7aea8e84d662fec7761495e09e`. No existen pull requests abiertos. Los commits más recientes son de agosto de 2026 y tratan de worklog, revisión de conversión, accesibilidad/componentes e instrumentación, no de una implementación Bradesco × BCP.

**Implicación:** la investigación y los artefactos deben mantenerse en una ruta independiente; no se debe mutar el repositorio de referencia sin una etapa explícita de implementación, rama dedicada, tests RED y aprobación de escritura.

---

## B. Fechamento de perguntas / Cierre de preguntas

### 🇧🇷 Português (Brasil)

| ID | Resultado da Ronda 7 | Status |
|---|---|---|
| OQ-04 — investimento de TI BCP | O 6-K de 3T25 mostra despesas de TI e serviços terceirizados de TI de S/336,9 milhões no trimestre, contra S/287,4 milhões em 3T24; despesas operacionais cresceram 12,8% a/a. A série não fornece uma relação diretamente comparável com receita nem com o "+22%" de investimento tecnológico reportado pelo Bradesco. | `PARTIALLY_RESOLVED` / `NOT_DIRECTLY_COMPARABLE` |
| OQ-05 — detecção de fraude BCP >90% | Busca de atualização 2025-2026 encontrou protocolos públicos de prevenção a phishing e engenharia social, mas não uma métrica recente de desempenho de ML. | `STALE` |
| OQ-08 — caso CVM/UEG Araucária | A CVM aceitou termo de compromisso para BEM DTVM e diretor: R$750 mil atribuídos à BEM e R$250 mil ao diretor; é acordo administrativo, não mensuração do prejuízo civil/multimilionário ainda sob perícia. | `PARTIALLY_RESOLVED` |
| OQ-09 — litígio Bradesco >20% do lucro líquido | A busca não localizou passivo ativo e quantificado equivalente, mas ausência de resultado não prova ausência de passivo. Exige leitura completa de contingências do 20-F. | `BLOCKED_BY_SOURCE_GAP` |

### 🇵🇪 Español (Perú)

| ID | Resultado de la Ronda 7 | Estado |
|---|---|---|
| OQ-04 — inversión TI BCP | El 6-K de 3T25 muestra gastos de TI y servicios de terceros de TI por S/336,9 millones en el trimestre, frente a S/287,4 millones en 3T24; los gastos operativos crecieron 12,8% interanual. La serie no entrega una relación directamente comparable con ingresos ni con el "+22%" de inversión tecnológica reportado por Bradesco. | `PARTIALLY_RESOLVED` / `NOT_DIRECTLY_COMPARABLE` |
| OQ-05 — detección de fraude BCP >90% | La búsqueda de actualización 2025-2026 encontró protocolos públicos contra phishing e ingeniería social, pero no una métrica reciente de desempeño de ML. | `STALE` |
| OQ-08 — caso CVM/UEG Araucária | La CVM aceptó un término de compromiso para BEM DTVM y su director: R$750 mil atribuibles a BEM y R$250 mil al director; es un acuerdo administrativo, no una medición de las pérdidas civiles/multimillonarias que siguen bajo pericia. | `PARTIALLY_RESOLVED` |
| OQ-09 — litigio Bradesco >20% de utilidad neta | La búsqueda no localizó pasivo activo y cuantificado equivalente, pero la ausencia de resultado no prueba ausencia de pasivo. Requiere lectura completa de contingencias del 20-F. | `BLOCKED_BY_SOURCE_GAP` |

---

## C. Rotas de continuidade / Rutas de continuidad

### Rota 1 / Ruta 1 — Fechamento de evidência / Cierre de evidencia

**🇧🇷** Usar a seção de contingências do 20-F/relatório anual Bradesco 2025 como fonte primária de OQ-09. Extrair apenas: processo, natureza, valor provisionado/possível, estágio, entidade no perímetro e data de corte. Não confundir proposta de acordo CVM com valor do dano civil.

**🇵🇪** Usar la sección de contingencias del 20-F/reporte anual Bradesco 2025 como fuente primaria de OQ-09. Extraer únicamente: proceso, naturaleza, monto provisionado/posible, etapa, entidad en el perímetro y fecha de corte. No confundir la propuesta de acuerdo CVM con el valor del daño civil.

**Gate:** `RESOLVED` apenas se a fonte primária quantificar; caso contrário, manter `BLOCKED_BY_SOURCE_GAP`.

### Rota 2 / Ruta 2 — Implementação do command center / Implementación del command center

**🇧🇷** Criar uma branch separada e implementar primeiro os registries e o claim graph. Depois, os módulos 00, 01, 02, 06, 07, 09, 12, 13, 14 e 16 — os módulos já respaldados pela evidência. Os módulos 04/05 devem usar os artefatos de catálogo/jornada já produzidos.

**🇵🇪** Crear una rama separada e implementar primero los registros y el grafo de claims. Luego, los módulos 00, 01, 02, 06, 07, 09, 12, 13, 14 y 16 — los módulos ya respaldados por evidencia. Los módulos 04/05 deben usar los artefactos de catálogo/journey ya producidos.

**Gate:** tests RED pasan antes de contenido visual; ningún dato se hardcodea fuera de registros.

### Rota 3 / Ruta 3 — Ferramentas e QA / Herramientas y QA

**🇧🇷** Construir somente seis ferramentas úteis para decisão: Metric Normalizer, Bank Scale Comparator, Technology Capability Heatmap, Initiative Lifecycle Explorer, Contradiction Explorer e Source Freshness Monitor. Executar acessibilidade de teclado, equivalentes textuais de visuais, viewport móvel e impressão.

**🇵🇪** Construir solo seis herramientas útiles para la decisión: Metric Normalizer, Bank Scale Comparator, Technology Capability Heatmap, Initiative Lifecycle Explorer, Contradiction Explorer y Source Freshness Monitor. Ejecutar accesibilidad de teclado, equivalentes textuales de visuales, viewport móvil e impresión.

**Gate:** cada ferramenta mostra entidade, perímetro, métrica, definição, unidade, período, fonte e confiança; métricas `NOT_DIRECTLY_COMPARABLE` não podem ser ranqueadas.

### Rota 4 / Ruta 4 — Release adversarial / Lanzamiento adversarial

**🇧🇷** Rodar duas verificações independentes: fontes erradas, fontes obsoletas, duplicação/sindicação, colisões de entidade, claims sem proveniência, ciclos de citação e comparações inválidas.

**🇵🇪** Ejecutar dos verificaciones independientes: fuentes erróneas, fuentes obsoletas, duplicación/sindicación, colisiones de entidad, claims sin procedencia, ciclos de citación y comparaciones inválidas.

**Gate:** só emitir `READY_FOR_EXECUTIVE_REVIEW` se nenhuma verificação criar achado material novo. Caso contrário, manter `CONDITIONALLY_READY` ou rebaixar conforme o bloqueio.

---

## D. Invariantes operacionais / Invariantes operativos

### 🇧🇷

- Toda recomendação deve citar claims favoráveis, claims contraditórios, premissas, confiança e o que mudaria a conclusão.
- `UNKNOWN`, `STALE` e `BLOCKED_BY_SOURCE_GAP` são resultados válidos e visíveis, não falhas a esconder.
- Dados de cliente (Reclame Aqui/app stores) são sinais, não estimativas populacionais.
- Todo comparativo precisa declarar entidade, perímetro, geografia, período, moeda, definição e base contábil.

### 🇵🇪

- Toda recomendación debe citar claims favorables, claims contradictorios, supuestos, confianza y qué cambiaría la conclusión.
- `UNKNOWN`, `STALE` y `BLOCKED_BY_SOURCE_GAP` son resultados válidos y visibles, no fallas que ocultar.
- Los datos de clientes (Reclame Aqui/app stores) son señales, no estimaciones poblacionales.
- Toda comparación debe declarar entidad, perímetro, geografía, período, moneda, definición y base contable.

---

*Registro bilingüe de intención entre rutas. Análisis estratégico independiente; sin afiliación con Bradesco, BCP, Credicorp ni los proveedores/reguladores citados.*
