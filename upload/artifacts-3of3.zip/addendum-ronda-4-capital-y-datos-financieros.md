# Addendum — Ronda 4: Verificación con Datos Financieros en Tiempo Real y Repositorio GitHub

## Nota de continuidad

Esta ronda incorporó dos fuentes nuevas no usadas en rondas anteriores: (1) acceso directo al repositorio GitHub de referencia (`PillB/AIMarket-Design-Consulting-Reports`, HEAD confirmado en `806e6fd5fb4a5f7aea8e84d662fec7761495e09e`), verificando que la arquitectura documentada en las rondas anteriores (BUILD_SPEC.md, `methodology/`, `agent-ctx/`, `worklog.md`, `research/`, `src/`, `tests/`) corresponde exactamente al estado real del repositorio; y (2) un proveedor de datos financieros en tiempo real, que constituye un **cluster de independencia nuevo y distinto** de la prensa financiera y los filings SEC ya usados — permitiendo verificación cruzada genuina, no solo repetición de las mismas fuentes.

## 1. Hallazgo material nuevo: aumento de capital de Bradesco (29 de julio de 2026)

El 29 de julio de 2026, el Consejo de Administración de Bradesco aprobó un aumento de capital de hasta R$10 mil millones mediante suscripción privada, únicamente para accionistas ya existentes. Los accionistas controladores (Cidade de Deus, Fundação Bradesco, NCF Participações) se comprometieron a suscribir hasta R$8 mil millones del total. El capital social se elevará de R$93,77 mil millones a hasta R$103,77 mil millones, con emisión de hasta 604,85 millones de nuevas acciones (ON a R$15,43, PN a R$17,64, con 6% de descuento respecto al cierre previo) [web:155][web:147].

El banco adelantó además el pago de R$6,5 mil millones en JCP (juros sobre capital próprio) ya declarados, originalmente previstos para octubre 2026 y enero 2027, ahora anticipados al 15 de septiembre de 2026 — recursos que los accionistas pueden usar directamente para suscribir el aumento de capital [web:147][web:155]. Bradesco proyecta que la operación eleve su índice de Capital Principal en aproximadamente 0,9 puntos porcentuales, alcanzando un nivel pro forma de ~12,7% [web:155].

**Clasificación de evidencia:** `VERIFIED` — hecho de importancia comunicado a la CVM/mercado, corroborado por seis fuentes de prensa financiera independiente (Valor, Folha, InfoMoney, O Globo, UOL, Seu Dinheiro) y por el propio proveedor de datos financieros vía análisis de sentimiento de mercado.

**Interpretación con hipótesis alternativas (disciplina de la Sección V del framework):**
- H1 — Señal de debilidad: el banco necesita capital porque el turnaround aún no genera suficiente capital orgánico.
- H2 — Señal de fortaleza/ambición: según fuentes de prensa citando a fuentes cercanas al banco, el aporte no fue motivado por problemas de crédito o liquidez sino por una decisión estratégica de los controladores para sostener inversión en tecnología, eficiencia comercial y expansión de negocio en la fase de aceleración del plan 2024-2028 [web:159][web:148].
- El propio CEO Noronha declaró públicamente: "Un capital robusto es siempre muy saludable para una organización bancaria" [web:161] — lenguaje calibradamente neutro, consistente con el estilo de comunicación "sin bala de plata" ya documentado en la Sección 23 del informe principal.

No hay evidencia pública suficiente para concluir de forma definitiva cuál hipótesis pesa más; ambas son plausibles y no mutuamente excluyentes.

## 2. Resultados del 2T26: décimo trimestre consecutivo de mejora de ROE

Bradesco reportó, el 5 de agosto de 2026, utilidad neta recurrente de R$7,05 mil millones en el segundo trimestre de 2026 (+16,2% interanual, +3,5% trimestral), con ROAE de 16,2% — el décimo trimestre consecutivo de mejora desde el inicio de la reestructuración [web:157][web:150]. Los ingresos alcanzaron R$37,6 mil millones (+10,3% interanual), superando el consenso de mercado [web:161]. La utilidad contable (no recurrente) fue de R$12,08 mil millones, afectada por eventos extraordinarios negativos de R$1,78 mil millones relacionados con la adhesión al PTI (programa de transacción tributária) y procesos fiscales [web:153].

Esta cifra de ROAE 16,2% **actualiza y supera** la cifra de 15,2% del 4T25 reportada en la Sección 1 del informe principal, confirmando que la trayectoria de mejora de rentabilidad documentada en la Sección 23 (arqueología histórica del plan Noronha) continúa de forma consistente dos trimestres después. El propio dato del proveedor financiero en tiempo real confirma un patrón de sorpresas positivas de ingresos en cada uno de los últimos cinco trimestres reportados (Q2 2025 a Q2 2026), aunque el BPA (EPS) del 2T26 en dólares (US$0,125) quedó ligeramente por debajo del consenso (US$0,1303) [web:161].

**Reclasificación:** la tendencia de mejora de ROE de Bradesco pasa de `STRONGLY_SUPPORTED` (Sección 23, basada en declaraciones de management) a `INDEPENDENTLY_CORROBORATED`, al confirmarse con datos de mercado en tiempo real de un proveedor financiero distinto de la prensa y de los propios comunicados del banco.

## 3. Contraste de capital regulatorio: hallazgo comparativo nuevo

La SBS peruana confirma que BCP cerró 2025 con un **Ratio de Capital Global de 19,44%**, por encima del promedio del sistema bancario peruano (18,15%) y en trayectoria ascendente sostenida (14,43% en 2022 → 17,46% en 2023 → 18,71% en 2024 → 19,44% en 2025) [web:162][web:165]. Esto contrasta con Bradesco, que necesitó una inyección de capital extraordinaria de hasta R$10 mil millones para elevar su índice de Capital Principal en solo ~0,9 puntos porcentuales hasta un nivel pro forma de ~12,7% [web:155].

**Gate de comparabilidad aplicado:** "Ratio de Capital Global" (Perú, patrimonio efectivo total/activos ponderados por riesgo bajo Basilea III con adaptaciones locales) y "Índice de Capital Principal" (Brasil, Common Equity Tier 1 bajo Basel III/normas del Banco Central do Brasil) **no son la misma métrica** — miden componentes de capital distintos (capital global incluye Nivel 1 + Nivel 2; Capital Principal es solo CET1). Comparar 19,44% directamente con 12,7% **sobreestimaría la brecha real** entre ambos bancos, porque el capital global de Bradesco sería una cifra más alta que su Capital Principal. Esta comparación se etiqueta `NOT_DIRECTLY_COMPARABLE` sin normalización adicional a un estándar común (p. ej., CET1 ratio de ambos bajo la misma definición) — trabajo pendiente que no fue posible completar en esta ronda.

Lo que sí puede afirmarse con evidencia: BCP mantiene una trayectoria de fortalecimiento de capital *orgánico y gradual* durante cuatro años consecutivos sin necesidad de una ronda de capital extraordinaria, mientras Bradesco recurrió a una inyección de capital puntual y extraordinaria en 2026. Esto es una diferencia real documentada, aunque su magnitud relativa exacta permanece como `OPEN_QUESTION` (OQ-08) hasta normalizar las métricas.

## 4. Confirmación de arquitectura societaria de BCP (dato nuevo)

Una fuente adicional (Rio Times, jun-2026) confirma que la estructura accionaria de BCP opera principalmente a través de Grupo Crédito S.A., subsidiaria de Credicorp Ltd., que posee el 97,7% del capital del banco — dejando solo ~2,3% cotizando libremente en la Bolsa de Valores de Lima bajo el ticker CREDITC1 [web:176]. Esto es coherente con y refuerza la disciplina de perímetros de la Sección 3 del informe principal: BCP no es una entidad de cotización pública independiente en la práctica, sino una subsidiaria casi totalmente controlada por Credicorp — reforzando por qué la Comparación A (BCP stand-alone) depende de datos consolidados internos de Credicorp/SBS en lugar de datos de mercado bursátil independientes para BCP.

## 5. Dividendos de Credicorp — dato primario adicional

El directorio de Credicorp aprobó, el 23 de abril de 2026, un dividendo en efectivo total de S/4.719.115.850 (S/50,00 por acción sobre 94.382.317 acciones), pagado el 12 de junio de 2026 en dólares estadounidenses, sin retención de impuestos en la fuente [web:164][web:170]. Esta cifra corresponde a la utilidad neta 2025 de S/6.925.376.887,42 ya documentada en la Sección 3 del informe principal, con un payout ratio implícito de ~68% de la utilidad neta 2025 — información que no había sido capturada en rondas anteriores y que añade una dimensión de política de retorno de capital a la comparación entre ambas instituciones.

## 6. Verificación de repositorio de referencia (Round Zero — repository archaeology)

Se confirmó vía GitHub API que el repositorio de referencia `PillB/AIMarket-Design-Consulting-Reports` existe con HEAD SHA `806e6fd5fb4a5f7aea8e84d662fec7761495e09e` y contiene exactamente la estructura documentada en el `StrategicCompanyIntelligenceFramework` entregado en la sesión anterior: `BUILD_SPEC.md`, `agent-ctx/`, `docs/`, `methodology/`, `research/`, `skills/`, `src/`, `tests/`, `worklog.md` (405 KB, consistente con un log extenso de trabajo acumulado), además de un stack Next.js con Prisma/DB, Tailwind, ESLint y un directorio `mini-services/`. Esto confirma con evidencia primaria — no solo con memoria de la sesión anterior — que la generalización metodológica entregada en `docs/framework/*.md` está correctamente alineada con la arquitectura real de Ursa, cerrando cualquier duda residual sobre la fidelidad de esa generalización.

## 7. Registro de preguntas abiertas — nuevas entradas

| ID | Tema | Estado |
|---|---|---|
| OQ-08 (nuevo) | Comparación normalizada de capital regulatorio CET1-equivalente entre Bradesco y BCP | `OPEN_QUESTION` — métricas actualmente no directamente comparables |
| RESUELTO | Trayectoria de ROE de Bradesco más allá del 4T25 | `INDEPENDENTLY_CORROBORATED` — confirma mejora hasta 2T26 (10 trimestres consecutivos) |
| NUEVO HECHO MATERIAL | Aumento de capital de R$10 mil millones (jul-2026) | `VERIFIED`, con hipótesis alternativas abiertas sobre motivación |

Este es un análisis estratégico independiente. No implica afiliación ni respaldo por parte de Bradesco, BCP, Credicorp, ni de los proveedores de datos financieros consultados.
