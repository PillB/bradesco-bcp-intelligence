# Roteiro Bilíngue de Fases e Próximos Passos / Hoja de Ruta Bilingüe de Fases y Próximos Pasos

**Programa / Programa:** Bradesco × BCP — Centro de Comando de Inteligência Estratégica / Centro de Comando de Inteligencia Estratégica
**Data / Fecha:** 2026-08-10
**Estado do gate / Estado de la puerta:** `CONDITIONALLY_READY` / `CONDITIONALLY_READY`

---

## 1. Estado atual por fase / Estado actual por fase

### 🇧🇷 Português (Brasil)

| Fase | Escopo | Status |
|---|---|---|
| Round 0 — Arqueologia do repositório | Inspeção do repo Ursa, BUILD_SPEC, worklog | ✅ Concluído |
| Round 1 — Framework / verdade evidencial | 15 docs em `docs/framework/*.md` | ✅ Concluído |
| Ciclo 1 — Entidade e história estratégica | entity-registry, perímetros | ✅ Concluído |
| Ciclo 2 — Escala e economia | scale-scorecard (FY2025) | ✅ Concluído |
| Ciclo 3 — Clientes e canais | Segmentação Bradesco + BCP (OQ-02 resolvida) | ✅ Concluído |
| Ciclo 4 — Ecossistema de produtos | Catálogos Bradesco e BCP | ✅ Concluído (nível catálogo) |
| Ciclo 5 — Plataformas e jornadas | Apps, onboarding, canais digitais | ✅ Concluído (nível jornadas principais) |
| Ciclo 6 — Tecnologia / IA / Dados / Cloud / Cyber | BIA, Bridge, BIA Tech, SAFER, Drex, quântica, CriptoCocos | ✅ Concluído |
| Ciclo 7 — Sistema operacional de inovação | Inovabra vs. Yape/Krealo/BCP Xplore | ✅ Concluído |
| Ciclo 8 — Arqueologia histórica | Turnaround Noronha vs. continuidade Ferrari | ✅ Concluído |
| Ciclo 9 — Inteligência externa | Reclame Aqui, Ouvidoria, vagas, ESG | ✅ Concluído |
| Ciclo 10 — Síntese comparativa / Red Team | comparative-strategy.json, 8 perguntas red-team | ✅ Concluído |
| Round 3 — Release adversarial | final-research-gate.json | ⚠️ Parcial (veredito CONDITIONALLY_READY) |

### 🇵🇪 Español (Perú)

| Fase | Alcance | Estado |
|---|---|---|
| Ronda 0 — Arqueología del repositorio | Inspección del repo Ursa, BUILD_SPEC, worklog | ✅ Concluido |
| Ronda 1 — Framework / verdad evidencial | 15 docs en `docs/framework/*.md` | ✅ Concluido |
| Ciclo 1 — Entidad e historia estratégica | entity-registry, perímetros | ✅ Concluido |
| Ciclo 2 — Escala y economía | scale-scorecard (FY2025) | ✅ Concluido |
| Ciclo 3 — Clientes y canales | Segmentación Bradesco + BCP (OQ-02 resuelta) | ✅ Concluido |
| Ciclo 4 — Ecosistema de productos | Catálogos Bradesco y BCP | ✅ Concluido (nivel catálogo) |
| Ciclo 5 — Plataformas y journeys | Apps, onboarding, canales digitales | ✅ Concluido (nivel journeys principales) |
| Ciclo 6 — Tecnología / IA / Datos / Cloud / Cyber | BIA, Bridge, BIA Tech, SAFER, Drex, cuántica, CriptoCocos | ✅ Concluido |
| Ciclo 7 — Sistema operativo de innovación | Inovabra vs. Yape/Krealo/BCP Xplore | ✅ Concluido |
| Ciclo 8 — Arqueología histórica | Turnaround Noronha vs. continuidad Ferrari | ✅ Concluido |
| Ciclo 9 — Inteligencia externa | Reclame Aqui, Ouvidoria, vacantes, ESG | ✅ Concluido |
| Ciclo 10 — Síntesis comparativa / Red Team | comparative-strategy.json, 8 preguntas red-team | ✅ Concluido |
| Ronda 3 — Release adversarial | final-research-gate.json | ⚠️ Parcial (veredicto CONDITIONALLY_READY) |

---

## 2. Perguntas abertas pendentes / Preguntas abiertas pendientes

### 🇧🇷 Português

| ID | Pergunta | Ação necessária | Prioridade |
|---|---|---|---|
| OQ-01 | Redução de 89% em revisões manuais (SAFER) tem corroboração de imprensa independente? | Buscar fonte Tier C sobre SAFER/FICO | Média |
| OQ-04 | Gasto de tecnologia/IA do BCP como % da receita, comparável ao crescimento de 22% do Bradesco? | Buscar no 20-F / Memoria Integrada do BCP linha de gasto em tecnologia | Alta |
| OQ-05 | A taxa de detecção de fraude >90% do BCP (2022) ainda é vigente? | Buscar fonte 2025-2026 sobre fraude no BCP | Média |
| OQ-08 | Monto exato em disputa no caso CVM/UEG Araucária? | Consultar bases da CVM / imprensa especializada | Alta |
| OQ-09 | Existe litígio ativo do Bradesco >20% do lucro líquido anual (equivalente ao caso SUNAT)? | Buscar no 20-F do Bradesco seção de contingências | Alta |

### 🇵🇪 Español

| ID | Pregunta | Acción necesaria | Prioridad |
|---|---|---|---|
| OQ-01 | ¿La reducción de 89% en revisiones manuales (SAFER) tiene corroboración de prensa independiente? | Buscar fuente Tier C sobre SAFER/FICO | Media |
| OQ-04 | ¿Gasto en tecnología/IA de BCP como % de ingresos, comparable al crecimiento de 22% de Bradesco? | Buscar en el 20-F / Memoria Integrada de BCP la línea de gasto tecnológico | Alta |
| OQ-05 | ¿La tasa de detección de fraude >90% de BCP (2022) sigue vigente? | Buscar fuente 2025-2026 sobre fraude en BCP | Media |
| OQ-08 | ¿Monto exacto en disputa en el caso CVM/UEG Araucaría? | Consultar bases de la CVM / prensa especializada | Alta |
| OQ-09 | ¿Existe litigio activo de Bradesco >20% de la utilidad neta anual (equivalente al caso SUNAT)? | Buscar en el 20-F de Bradesco la sección de contingencias | Alta |

---

## 3. Próximos passos formalizados / Próximos pasos formalizados

### 🇧🇷 Português (Brasil)

**Passo 1 — Fechamento de evidência (curto prazo).** Executar buscas dirigidas para OQ-04, OQ-08 e OQ-09 (prioridade alta), usando o 20-F do Bradesco (seção de contingências legais), o 20-F/Memoria Integrada do BCP (linha de gasto em tecnologia) e os portais da CVM. Critério de saída: cada OQ passa a `RESOLVED` ou `BLOCKED_BY_SOURCE_GAP` com justificativa registrada.

**Passo 2 — Construção do command center (médio prazo).** Instanciar o software: registries (COMPANY, ENTITY, MODULE, TOOL, SOURCE, CLAIM, METRIC_DICTIONARY, TECHNOLOGY, INITIATIVE, COMPARATOR), claim graph navegável, e os 17 módulos (00 Executive Command Center → 16 Sources/Claims/Contradictions/Open Questions). Tema visual novo — sem reutilizar a paleta Ursa nem a identidade visual de nenhum dos bancos analisados.

**Passo 3 — Ferramentas interativas (médio prazo).** Selecionar apenas ferramentas com valor de decisão: Bank Scale Comparator, Metric Normalizer, Technology Capability Heatmap, Initiative Lifecycle Explorer, Contradiction Explorer, Source Freshness Monitor. Cada ferramenta lê apenas dos registries — nunca de conteúdo hard-coded.

**Passo 4 — Verificação adversarial e release (gate final).** Executar os testes RED obrigatórios (sem conteúdo Ursa no relatório-alvo; fontes WRONG_ENTITY rejeitadas; métricas incomparáveis não ranqueadas; todo número com proveniência; fontes STALE com aviso visível), depois lint/typecheck/build/QA mobile/teclado/acessibilidade/impressão, e duas rodadas independentes de verificação silenciosa. Só então emitir `READY_FOR_EXECUTIVE_REVIEW` — ou manter `CONDITIONALLY_READY`/`NOT_READY` se o padrão de evidência não for atingido.

### 🇵🇪 Español (Perú)

**Paso 1 — Cierre de evidencia (corto plazo).** Ejecutar búsquedas dirigidas para OQ-04, OQ-08 y OQ-09 (prioridad alta), usando el 20-F de Bradesco (sección de contingencias legales), el 20-F/Memoria Integrada de BCP (línea de gasto en tecnología) y los portales de la CVM. Criterio de salida: cada OQ pasa a `RESOLVED` o `BLOCKED_BY_SOURCE_GAP` con justificación registrada.

**Paso 2 — Construcción del command center (mediano plazo).** Instanciar el software: registros (COMPANY, ENTITY, MODULE, TOOL, SOURCE, CLAIM, METRIC_DICTIONARY, TECHNOLOGY, INITIATIVE, COMPARATOR), grafo de claims navegable, y los 17 módulos (00 Executive Command Center → 16 Sources/Claims/Contradictions/Open Questions). Tema visual nuevo — sin reutilizar la paleta Ursa ni la identidad visual de ninguno de los bancos analizados.

**Paso 3 — Herramientas interactivas (mediano plazo).** Seleccionar solo herramientas con valor de decisión: Bank Scale Comparator, Metric Normalizer, Technology Capability Heatmap, Initiative Lifecycle Explorer, Contradiction Explorer, Source Freshness Monitor. Cada herramienta lee solo de los registros — nunca de contenido hard-coded.

**Paso 4 — Verificación adversarial y release (puerta final).** Ejecutar los tests RED obligatorios (sin contenido Ursa en el informe objetivo; fuentes WRONG_ENTITY rechazadas; métricas incomparables no rankeadas; todo número con procedencia; fuentes STALE con aviso visible), luego lint/typecheck/build/QA móvil/teclado/accesibilidad/impresión, y dos rondas independientes de verificación silenciosa. Solo entonces emitir `READY_FOR_EXECUTIVE_REVIEW` — o mantener `CONDITIONALLY_READY`/`NOT_READY` si el estándar de evidencia no se alcanza.

---

## 4. Regras permanentes (não negociáveis) / Reglas permanentes (no negociables)

### 🇧🇷
- Nenhum número sem fonte citada e rastreável.
- Nenhuma comparação sem passar pelo gate de comparabilidade (entidade, perímetro, geografia, período, moeda, definição de métrica, base contábil).
- `UNKNOWN` é resposta aceitável; silêncio não é evidência de falha.
- Nunca afirmar como executada uma busca, teste, commit ou deploy que não ocorreu.
- Nunca rebaixar o padrão de evidência para forçar um `READY`.

### 🇵🇪
- Ningún número sin fuente citada y rastreable.
- Ninguna comparación sin pasar por el gate de comparabilidad (entidad, perímetro, geografía, período, moneda, definición de métrica, base contable).
- `UNKNOWN` es una respuesta aceptable; el silencio no es evidencia de fracaso.
- Nunca afirmar como ejecutada una búsqueda, prueba, commit o despliegue que no ocurrió.
- Nunca bajar el estándar de evidencia para forzar un `READY`.

---

*Documento de acompanhamento de intencionalidade entre rotas / Documento de seguimiento de intencionalidad entre rutas. Análisis estratégico independiente; sin afiliación con Bradesco, BCP, Credicorp ni terceros citados.*
