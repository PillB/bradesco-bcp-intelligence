# Anexo 2 — Ciclos 4 y 5: Ecosistema de Productos y Plataformas/Journeys (Ronda 6)

## 36. Ciclo 4 — Ecosistema de productos y servicios

### Bradesco (perímetro banco + grupo)

El catálogo público de Bradesco confirma una arquitectura de banco múltiple completo[cite:274][cite:268]:

- **Cuentas/depósitos:** conta corrente, poupança, Click Conta (menores), Bradesco Universitário, cuenta INSS, conta-salário; cestas de servicios desde isenta (Next) hasta R$64,70/mes (Classic Mais).
- **Crédito:** crédito inmobiliario, financiamiento de vehículos, crédito consignado (nómina), crédito personal con garantía de inmueble (hasta 60% del valor, 240 meses), cheque especial, crédito parcelado[cite:268].
- **Tarjetas:** 18 tipos activos en banderas Visa, Mastercard, Elo y American Express, segmentados por rango de ingreso (desde R$937 hasta +R$20.000/mes), incluyendo líneas premium (Visa Infinite, Elo Nanquim, The Platinum Card)[cite:274].
- **Inversión:** LCI, poupança, CDB, fondos, previsión, renta variable vía Ágora[cite:274].
- **Seguros/pensión/capitalización:** accidentes, auto, dental, residencial, viaje, protección digital; vida y previsión; capitalización (Pé Quente)[cite:274].
- **Consorcios:** autos, inmuebles, motos, camiones — producto estructuralmente brasileño sin equivalente directo en Perú[cite:274].
- **Cambio/internacional:** moneda extranjera, remesas, tarjeta prepago[cite:274].

### BCP (perímetro banco)

La evidencia de la app y canales confirma un catálogo igualmente completo en su mercado[cite:263][cite:261]:

- **Cuentas/depósitos:** apertura de cuenta de ahorros digital en minutos desde la app; depósitos a plazo; metas de ahorro ("Wardaditos").
- **Crédito:** préstamos personales, tarjetas, crédito vehicular, hipotecario, MiVivienda — solicitables sin ir a agencia.
- **Pagos:** transferencias interbancarias inmediatas sin comisión, pago QR, Yape-a-celular integrado, retiro sin tarjeta en cajeros y agentes BCP, Apple Pay.
- **Inversión/seguros:** fondos mutuos y depósitos a plazo desde el celular; cotización y contratación de seguro vehicular/salud en minutos.
- **Cambio:** soles↔dólares con tipo de cambio en tiempo real desde la app.
- **Empresas:** app Telecrédito Móvil exclusiva para empresas, con aprobación de operaciones pendientes de firma[cite:264].

**Nota de comparabilidad:** los consorcios (Bradesco) no tienen equivalente peruano; MiVivienda (BCP) es un programa hipotecario subsidiado por el Estado peruano sin equivalente directo en el catálogo Bradesco. Ambos catálogos son "completos" dentro de su mercado — las diferencias reflejan estructura de mercado, no brecha de capacidad.

## 37. Ciclo 5 — Plataformas digitales y journeys

### BCP — madurez de canales digitales (evidencia primaria fuerte)

- **95% de los clientes empresariales usan exclusivamente canales digitales** (ene-2025); Telecrédito BCP migró todas sus funcionalidades a digital, incluyendo gestión de usuarios empresa sin instrucción física y financiamientos 100% en línea[cite:271].
- **Yape eliminó la clave de 6 dígitos** como método principal en 2025, migrando a biometría (huella/rostro) con validación por código[cite:266] — una señal de madurez en identidad digital comparable a las prácticas de Bradesco.
- La app BCP soporta apertura de cuenta digital completa, token digital con reconocimiento facial + DNI, y onboarding sin agencia[cite:263][cite:270].

### Bradesco — journeys

- Onboarding digital con atención por WhatsApp ((11) 3335-0237) y chat dentro del app[cite:269].
- 99% de las transacciones en canales digitales (cifra corporativa, Sección 1 del informe principal)[cite:21].
- 19M clientes plenamente digitales (fin-2025) → 28M (1T26)[cite:69][cite:79].

**Hallazgo de simetría:** ambos bancos reportan niveles de digitalización de transacciones muy altos (95%+ empresas en BCP; 99% transacciones en Bradesco) — la digitalización de canales transaccionales es un juego de mesa ("table stakes") en ambos mercados, no un diferenciador. El diferencial observable está en la capa de IA generativa (Bradesco más visible) y en cripto regulado (BCP adelante), como se documentó en la Ronda 5.

**Estado de los ciclos:** Ciclo 4 → `COMPLETO` (nivel catálogo); Ciclo 5 → `COMPLETO` (nivel journeys principales). Pendiente de profundización opcional: journey maps detallados paso a paso con métricas de conversión (no publicadas por ninguno de los dos bancos — sería `OPEN_QUESTION` permanente por falta de fuente pública).
