# Lifecycle Methodology

## 1. Initiative Lifecycle States

`DISCOVERED, ANNOUNCED, RESEARCH, EXPERIMENT, POC, PILOT, BETA, PRODUCTION, SCALING, MATURE, INTEGRATED, REPOSITIONED, PAUSED, SUNSET, SOLD, FAILED, UNKNOWN`.

`UNKNOWN` is an acceptable and frequently correct answer. Silence in public sources is not evidence of failure — it is evidence of insufficient public information, and must be recorded as such.

## 2. Success / Failure Criteria

An initiative is not "successful" merely because it won an award, appeared in a press release, or was praised by an executive — those are Tier B promotional signals, not outcome evidence.

Plausible success evidence: adoption, user counts, transaction volume, revenue, margin, productivity gains, cost reduction, risk reduction, conversion improvement, time-to-market improvement, business expansion, repeat deployment across business units, continued investment over multiple periods.

Plausible failure evidence: explicit closure announcement, write-off, abandonment, a failed KPI disclosed by the organization, management admission of failure, withdrawal after a test/pilot, regulatory rejection, or a documented material inability to scale.

## 3. Outcome Classification

`SUCCESS, PARTIAL_SUCCESS, LEARNING_EXPERIMENT, INTEGRATED, REBRANDED, SUNSET, FAILED, UNKNOWN`.

## 4. Original Promise vs. Later Outcome

Historical archaeology (Research Cycle 8) explicitly pairs an initiative's original announced promise with its later, independently verifiable outcome. A gap between promise and outcome is reported neutrally and evidentially — not spun toward either an "innovation success story" or a "failure story" beyond what the evidence supports.
