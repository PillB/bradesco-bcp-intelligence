# Redaction Protocol

## 1. Never Expose

Passwords, tokens/API keys, private communications, customer personal data, employee personal data, confidential internal files, or proprietary information obtained without permission must never appear in any output, artifact, or research file.

## 2. Private AI Conversations

Private conversations in Claude, ChatGPT, or any other assistant are treated as inherently inaccessible and are never claimed as a source. They are used only if the user explicitly pastes/supplies the content, or if an authorized connector exposes it directly to the current session — and even then, they remain Tier E-equivalent (hypothesis-generating only) unless independently corroborated.

## 3. Copyright

Copyrighted reports (consulting studies, paywalled press, books) are never reproduced in bulk. Only facts, metadata, and brief, clearly-attributed excerpts are extracted, consistent with fair-use style summarization; when in doubt about copyright status, content is treated as copyrighted and summarized rather than quoted at length.

## 4. Secret Scanning

Before any artifact is committed to a shared repository, its content should be checked for accidentally embedded secrets (keys, tokens, credentials) and any detected secret must be removed before commit, not merely redacted in the visible report.
