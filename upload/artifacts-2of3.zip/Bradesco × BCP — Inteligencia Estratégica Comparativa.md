## Nota metodológica y alcance

Este informe aplica de forma disciplinada —aunque a escala reducida frente a la arquitectura de "centro de comando" de 17 módulos y 30+ artefactos JSON descrita en el prompt maestro— los principios de resolución de entidades, jerarquía de fuentes, gate de comparabilidad y calibración de confianza definidos en el framework generalizado entregado previamente. No se han ejecutado los diez ciclos de investigación completos ni se ha construido el software del command center; lo que sigue es una síntesis basada en evidencia primaria y corroborada (informes 20-F, comunicados 6-K ante la SEC, transcripciones de resultados y prensa especializada), con fechas de evidencia explícitas y sin cifras inventadas. Donde la evidencia pública es insuficiente, se declara explícitamente `UNKNOWN` en lugar de inferir.

**Resolución de entidades (gate obligatorio):** Banco Bradesco S.A. (entidad operativa bancaria) es distinta de Organização Bradesco (el grupo, que incluye Bradesco Seguros); ambas se distinguen de sus marcas digitales Next, Digio y Ágora, que son subsidiarias 100% controladas pero con marcas y —en el caso de Digio— infraestructura tecnológica separada. En el lado peruano, Banco de Crédito del Perú (BCP) es la entidad bancaria "stand-alone"; Credicorp es el holding que la controla junto con Mibanco, Yape (que opera dentro de BCP) y Krealo; ambas son perímetros distintos y no deben mezclarse en una comparación directa.[^1][^2][^3][^4][^5]

## 1. Qué es Bradesco hoy: perímetro y escala

Banco Bradesco es un banco múltiple brasileño con sede en Osasco (São Paulo), que opera bajo dos segmentos reportables: banca y seguros/previsión/capitalización. Al cierre de 2025, los activos totales consolidados de Banco Bradesco S.A. bajo IFRS alcanzaron R$2,33 billones (trillion en la nomenclatura anglosajona), frente a R$2,07 billones en 2024. El segmento bancario por sí solo reportó R$2,04 billones en activos y el segmento de seguros R$507,8 mil millones.[^6][^7][^1]

La cartera de crédito ampliada cerró 2025 en R$1,089 billones, con un crecimiento de 11,0% interanual, y los depósitos totalizaron R$727,9 mil millones (+12,2%). El resultado recurrente de 2025 fue de R$24,7 mil millones, un incremento de 26,1% frente a 2024, con un ROAE (retorno sobre patrimonio promedio) de 15,2% en el 4T25 —la primera vez, según management, que dicho retorno supera el costo de capital de la entidad. Bradesco Seguros aportó R$10,1 mil millones de utilidad neta en 2025 (ROAE de 21,9%). El índice de eficiencia cerró en 50%, con una meta declarada de 40% para 2028.[^8][^9][^10][^7][^11][^6]

| Métrica | Banco Bradesco (banco operativo) | Fuente / as-of |
|---|---|---|
| Activos totales | R$2,33 billones | 20-F/6-K, dic-2025[^7] |
| Utilidad recurrente 2025 | R$24,7 mil millones (+26,1% a/a) | 6-K 4T25[^8] |
| ROAE 4T25 | 15,2% | 6-K 4T25[^9] |
| Cartera de crédito | R$1,089 billones (+11,0% a/a) | 6-K 4T25[^7] |
| Depósitos | R$727,9 mil millones (+12,2% a/a) | 20-F 2025[^6] |
| Índice de eficiencia | 50% (meta 40% en 2028) | Earnings call 4T25[^9] |
| Clientes plenamente digitales | 19 millones (fin-2025) → 28 millones (1T26) | Earnings call, mar-2026[^12][^13] |

**Confianza:** VERIFICADO — cifras provienen directamente de comunicados 6-K/20-F ante la SEC y transcripciones oficiales de la llamada de resultados, corroboradas de forma cruzada entre al menos tres documentos independientes de la propia compañía.

## 2. Estructura societaria y marcas digitales (Organização Bradesco)

La organización agrupa, además del banco matriz, entidades 100% controladas como Banco Bradesco BBI (banca de inversión), Banco Bradesco Financiamentos, Bradesco Leasing, Ágora Corretora (adquirida en 2008), Banco Bradescard (tarjetas), Bradseg Participações y Banco Digio. Next, lanzado en junio de 2017 como el primer banco 100% digital de Bradesco dirigido a público joven, fue formalmente reincorporado a la estructura operativa del banco matriz hacia fines de 2023-2024, pasando de operación separada a "segmento de atención" —una decisión estratégica explícita de la administración, no un fracaso comercial. Digio, en cambio, fue adquirido en su totalidad en 2021-2022 (comprando el 49,99% que pertenecía a Banco do Brasil por R$625 millones) y la administración declaró explícitamente su intención de mantenerlo como unidad independiente, con infraestructura en AWS separada de la de Next (Azure).[^2][^3][^14][^15][^1]

**Clasificación de ciclo de vida — Next:** `INTEGRATED` (reincorporado al banco matriz como segmento de marca, no un sunset ni un fracaso; la marca y el app continúan operando y siendo actualizados según Google Play, última actualización junio 2026). La cartera digital Bitz, lanzada en 2020, sí fue formalmente cerrada en 2023, con sus clientes migrados a Digio — este es un caso `SUNSET` confirmado explícitamente por management, distinto del caso Next.[^16][^14]

## 3. Perú: BCP y Credicorp — perímetros y escala

Bajo la Superintendencia de Banca, Seguros y AFP (SBS) del Perú, BCP es el mayor banco del país por activos. Al cierre de 2025, BCP Stand-alone (la entidad bancaria operativa, excluyendo Mibanco, BCP Bolivia y las unidades de innovación) reportó activos totales de S/204,9 mil millones (~US$54 mil millones), un aumento de 3,8% frente a S/197,5 mil millones en 2024. Su ROAE de 2025 fue de 24,7%, muy por encima del ROAE del grupo consolidado, impulsado por una fuerte caída del costo de riesgo (de 2,13% a 1,28%).[^4][^5]

Credicorp, el holding que cotiza en NYSE y controla BCP, Mibanco, Grupo Pacífico (seguros), Prima AFP y las iniciativas de innovación (Yape, Tenpo, Krealo), reportó activos totales consolidados de S/267,4 mil millones y una utilidad neta atribuible de S/6.925,4 millones en 2025 (+25,9% a/a), con un ROAE consolidado de 19,0%. BCP Stand-alone representó 75,6% de los activos totales del grupo y 65,2% del patrimonio atribuible en 2025.[^17][^5]

| Métrica | BCP Stand-alone (perímetro bancario) | Credicorp consolidado (perímetro de grupo) |
|---|---|---|
| Activos totales | S/204,9 mil millones (dic-2025)[^5] | S/267,4 mil millones (dic-2025)[^5] |
| ROAE 2025 | 24,7%[^5] | 19,0%[^17] |
| Utilidad neta 2025 | Contribución interna al grupo (no reportada de forma independiente en 20-F) | S/6.925,4 millones[^17] |
| % de activos del grupo | 75,6% del total Credicorp[^5] | — |

**Gate de comparabilidad:** una comparación directa de "Bradesco vs. BCP" en términos de activos totales (R$2,33 billones vs. S/204,9 mil millones) mezcla monedas (real vs. sol), tamaños de economía radicalmente distintos (PIB de Brasil ≈10x el de Perú) y perímetros no equivalentes si no se ajusta por escala relativa de mercado. La comparación analíticamente más defendible es de **rentabilidad y eficiencia relativa dentro de cada mercado**, no de tamaño absoluto. Etiqueto la comparación de tamaño absoluto como `NOT_DIRECTLY_COMPARABLE` sin normalización adicional (PIB, población bancarizada, cuota de mercado doméstica), que no fue posible completar con el tiempo de investigación disponible en esta sesión — `OPEN_QUESTION`.

Comparación B (grupo vs. grupo) — Organização Bradesco vs. Credicorp — es analíticamente más válida porque ambas son holdings multi-negocio (banca + seguros + digital), aunque persiste la asimetría de escala de mercado.

## 4. Inteligencia artificial: BIA, Bridge y el "AI First"

BIA (Bradesco Inteligência Artificial) es el asistente virtual del banco, lanzado en 2016 originalmente sobre el motor Watson de IBM, y hoy interactúa con más de 24 millones de usuarios en el app. Según declaraciones de ejecutivos del banco en junio de 2025, BIA está "100% integrada con IA generativa" y retiene entre 85% y 90% de las demandas en el canal de chat digital, con notas de satisfacción de 4,1-4,2 sobre 5. La llamada de resultados del 4T25 (fuente primaria, febrero de 2026) eleva esa cifra a 90% de las interacciones digitales gestionadas por BIA, con una reducción de ~40 veces en el costo directo de atención por esta vía.[^18][^19][^20][^12]

**Bridge** es la plataforma corporativa de IA generativa de Bradesco —descrita internamente como "Bradesco Inteligência de Data Generativa"— que centraliza procesamiento de documentos, voz y texto, desarrollo de asistentes y aplicación de barandas ("guardrails") de IA responsable. Según una entrevista de febrero de 2026 con la CTO del banco, Cíntia Scovine, Bridge opera con servicios reutilizables, multiagente y de voz en tiempo real, y "ya soporta más de 500 casos de uso en producción, con 70 a escala". Esta es la fuente primaria más específica disponible sobre el estado de madurez de Bridge; no encontré una fuente independiente (Tier C) que corrobore de forma cuantitativa esos 500 casos de uso, por lo que la cifra se clasifica `STRONGLY_SUPPORTED` (corporativa, con contexto consistente en otras fuentes del propio banco) más que `INDEPENDENTLY_CORROBORADO`.[^20][^11][^18]

La inversión en tecnología creció 22% en 2025 y se proyecta un crecimiento adicional de 16% en 2026, con más de 10.500 profesionales de tecnología a cierre de 2025 (≈6.500 internos), tras un incremento del 35% en desarrolladores desde 2024. Bradesco reporta reducción del *lead time* de desarrollo en 43% y un incremento de 118% en volumen de *features* de negocio entregadas, comparando fin de 2025 con fin de 2023. Estas son métricas auto-reportadas por la propia CTO, sin confirmación independiente — `STRONGLY_SUPPORTED`, no `VERIFIED`.[^11]

**Estado de madurez — BIA:** `PRODUCTION/SCALING` (evidencia consistente de múltiples fuentes primarias y de prensa especializada durante 2023-2026 sobre operación productiva a gran escala).
**Estado de madurez — Bridge:** `PRODUCTION` según fuente primaria única (CTO, feb-2026); confianza `STRONGLY_SUPPORTED`, pendiente de corroboración independiente — `OPEN_QUESTION`.

## 5. Nube y arquitectura tecnológica

Bradesco declaró explícitamente una estrategia **multicloud** en febrero de 2024: los sistemas nuevos nacen "cloud-first" (100% en la nube), pero el legado de 80 años de operación no se migra salvo necesidad efectiva de negocio. En esa fecha, 35% de las cargas de trabajo ya estaban en la nube. La distribución declarada por el propio banco fue: Next sobre Azure; Digio y la ya cerrada Bitz sobre AWS; Bradesco Seguros sobre Oracle; y el banco matriz usando una combinación de Azure, IBM y AWS. Un caso de estudio de julio de 2025 (Teradata/evento Possible) describe además una migración híbrida del entorno analítico de Teradata hacia Azure, con más de 400 TB de datos y 190.000 tablas, usando QueryGrid como capa de virtualización de datos entre on-premise y nube. Esta es evidencia de vendor case study (Tier B, con sesgo promocional inherente) y debe leerse como tal.[^15][^21]

**Estado de madurez — arquitectura cloud:** `SCALING` (la propia compañía declara la meta de "cloud-first" para sistemas nuevos, con migración parcial y deliberadamente incompleta del legado). No hay evidencia pública de una fecha objetivo de "100% cloud" — cualquier afirmación en ese sentido sería `HYPOTHESIS`, no `VERIFIED`.

## 6. Innovación abierta: Inovabra habitat

Inovabra habitat es el espacio de co-innovación de Bradesco, inaugurado en febrero de 2018 en un edificio de 22.000 m² en São Paulo, operado en sociedad con WeWork. En su primer año (2019) albergaba más de 190 startups y ~70 corporaciones, con 65.000 visitantes y 85 contratos firmados entre startups y corporaciones. Según el sitio oficial vigente (consultado julio 2026), el ecosistema actual declara conexión con 230 startups, 80 empresas y 8 hubs. La curaduría exige que las startups admitidas ya tengan producto y servicio maduro en el mercado —es decir, Inovabra opera como plataforma de escalamiento comercial más que como incubadora temprana.[^22][^23][^24][^25][^26]

**Estado de madurez — Inovabra habitat:** `MATURE/PRODUCTION` como programa (operando de forma continua desde 2018, con crecimiento sostenido de participantes documentado en múltiples años), aunque no encontré evidencia pública de resultados agregados de negocio (ingresos generados, número de soluciones llevadas a producción bancaria) más allá de conteos de participantes y contratos firmados en 2019 — `OPEN_QUESTION` sobre el retorno económico agregado del programa.

## 7. Innovación en BCP / Credicorp: comparación directa

A diferencia de Inovabra (espacio físico/ecosistema abierto), la innovación de Credicorp está organizada como una cartera de "iniciativas disruptivas" gestionadas con métricas de cartera de venture capital corporativo. Según la actualización de inversionistas de enero de 2026, estas iniciativas (lideradas por Yape, Tenpo, Culqi e iO) apuntan a generar 10% de los ingresos ajustados por riesgo del grupo hacia 2026. Yape —la aplicación de pagos que opera dentro del perímetro de BCP— alcanzó rentabilidad antes de lo proyectado y se espera que represente 65% de los ingresos de disrupción, con metas declaradas de 16,5 millones de usuarios activos y S/600 mil millones en transacciones anuales para 2026. Krealo es el fondo de venture corporativo del grupo, con un enfoque "hands-on" tipo VC y salidas estructuradas. BCP Xplore es la unidad de Open Banking/APIs de BCP, con servicios de recaudación, pagos automáticos y financiamiento flexible exclusivos para clientes de ese programa. Un antecedente de 2018 (proyecto CIX-BCP en GitHub) sugiere una plataforma interna más temprana de exhibición de proyectos de innovación, pero no hay evidencia reciente de que ese proyecto específico continúe activo — `UNKNOWN`.[^27][^28]

**Diferencia estructural clave:** Inovabra es un ecosistema abierto de coinvención con startups externas y grandes corporaciones (modelo "habitat"); el aparato de innovación de Credicorp es más una cartera interna de productos digitales cuasi-independientes con objetivos de contribución a ingresos explícitos y cuantificados. Ambos modelos tienen lógicas distintas y no deberían compararse como si fueran el mismo tipo de instrumento.

## 8. Hipótesis alternativas sobre la diferencia observada

**Observación:** Bradesco comunica públicamente un volumen mayor de iniciativas de IA/tecnología (Bridge, BIA, más de 500 casos de uso) que lo que Credicorp comunica para BCP en el mismo período.

- **H1 — Madurez real superior de Bradesco:** el banco efectivamente ha centralizado y escalado más casos de uso de IA en producción, apoyado por una inversión tecnológica mayor en términos absolutos (justificada por su escala de mercado).
- **H2 — Diferencia de estilo de comunicación corporativa:** Bradesco, como emisor listado en NYSE bajo escrutinio de analistas comparando bancos globales, tiene incentivos más fuertes para narrar una historia de transformación tecnológica cuantificada ("500 casos de uso", "40 veces menos costo"); Credicorp comunica sus métricas de innovación en términos de contribución a ingresos, un lenguaje financiero distinto que no es directamente comparable en granularidad de "casos de uso de IA".
- **H3 — El tamaño de Bradesco simplemente permite mayor volumen de experimentación**, sin que ello implique necesariamente una tasa de conversión a producción superior por unidad de inversión.
- **H4 — Diferencias regulatorias y de infraestructura de mercado** (Brasil tiene un ecosistema de Open Finance y Pix más maduro y de adopción obligatoria más temprana que el marco peruano) explican parte de la brecha de casos de uso digital observables, independientemente de la capacidad interna relativa de cada organización.

No encontré evidencia pública que permita discriminar de forma concluyente entre estas hipótesis; se declaran como `OPEN_QUESTIONS` explícitas.

## 9. Qué aprendizajes son razonablemente transferibles a BCP/Perú

- **Centralización de una plataforma de IA generativa con gobernanza única (tipo Bridge)** es un patrón replicable independientemente de la escala: la lógica de una capa horizontal de servicios de IA (documentos, voz, texto, agentes) con barandas de cumplimiento centralizadas no depende del tamaño del banco, aunque el volumen de casos de uso sí escala con los recursos disponibles.
- **La decisión de reincorporar una marca digital (Next) al banco matriz en lugar de mantenerla como entidad separada** sugiere que la fragmentación de marcas digitales puede generar costos de coordinación que superan sus beneficios de posicionamiento una vez que el banco matriz alcanza cierto nivel de madurez digital propia — un aprendizaje potencialmente relevante si Perú evaluara consolidar marcas digitales fragmentadas.
- **No es evidente que el modelo de "habitat" físico de coinvención (Inovabra) sea superior al modelo de cartera de venture interno de Credicorp (Yape/Tenpo/Krealo)** — son respuestas a contextos de mercado distintos y no hay evidencia comparativa de retorno que permita recomendar la transferencia de uno sobre el otro sin más investigación.
- **Qué no transferiría sin más evidencia:** cualquier cifra específica de Bradesco (90% de retención en BIA, 500 casos de uso en Bridge, 40x de reducción de costos) no debe usarse como benchmark objetivo para BCP sin ajustar por diferencias de base de clientes, madurez de infraestructura de datos y contexto regulatorio — hacerlo sería repetir el error H2/H3 señalado arriba.

## 10. Preguntas abiertas y qué evidencia cambiaría estas conclusiones

- No fue posible obtener, en el tiempo de esta sesión, datos comparables de "casos de uso de IA en producción" para BCP/Credicorp que permitan una comparación directa con los "500 casos de uso" declarados por Bradesco — una fuente primaria específica de Credicorp/BCP sobre esta métrica cambiaría sustancialmente el análisis de la Sección 8.
- El retorno económico agregado de Inovabra habitat (ingresos generados, soluciones llevadas a producción bancaria) no está públicamente cuantificado más allá de conteos de participantes de 2019 — un reporte de impacto más reciente y específico cambiaría la Sección 6.
- No se ejecutó una normalización de "tamaño" ajustada por PIB/población bancarizada entre Brasil y Perú — esa normalización, si se completara, podría cambiar sustancialmente la lectura de la Sección 3 sobre "quién es más grande relativo a su mercado".
- Este informe no cubrió (por restricción de alcance/tiempo, no por decisión editorial) los temas de digital identity, biometría, GNN, datos sintéticos, computación cuántica/QKD, ni la totalidad de acuerdos con big tech y universidades solicitados en el prompt original — quedan como `PendingRecords` explícitos para una futura ronda de investigación si se desea profundizar.

Este es un análisis estratégico independiente. No implica afiliación ni respaldo por parte de Bradesco, BCP o Credicorp.

---

## References

1. [Bradesco details global, digital and insurance operations](https://www.stocktitan.net/sec-filings/BBD/6-k-bank-bradesco-current-report-foreign-issuer-0067ece6c77e.html) - Banco Bradesco describes its banking and insurance segments, 99% digital transaction share, R$923.8B...

2. [Bradesco – Wikipédia, a enciclopédia livre](https://pt.wikipedia.org/wiki/Bradesco)

3. [Agora dono de 100% do Digio, Bradesco diz que vai ...](https://www.terra.com.br/economia/agora-dono-de-100-do-digio-bradesco-diz-que-vai-manter-autonomia-do-banco-digital,69ac63fae009efa25f1a58efcffd2bacxge4xut8.html) - Enquanto planeja expansão do Digio, instituição afirma que, por ora, também não pretende uni-lo ao N...

4. [Banco de Crédito del Perú - Wikipedia](https://en.wikipedia.org/wiki/Banco_de_Cr%C3%A9dito_del_Per%C3%BA)

5. [Credicorp 2025 20‑F details risks and structure | BAP SEC ...](https://www.stocktitan.net/sec-filings/BAP/20-f-credicorp-ltd-files-annual-report-foreign-issuer-73adbccbaa81.html) - Credicorp’s 2025 20‑F outlines its Peru‑centric banking group, BCP’s 75.6% asset share, IFRS Soles r...

6. [Banco Bradesco (NYSE: BBD) outlines 2025 macro, tax and risk ...](https://www.stocktitan.net/sec-filings/BBD/20-f-bank-bradesco-files-annual-report-foreign-issuer-2a2ff71e8ef9.html) - Banco Bradesco’s 2025 annual report under IFRS highlights Brazilian inflation, SELIC at 15%, tax ref...

7. [Banco Bradesco (NYSE: BBD) lifts 2025 profit and ... - Stock Titan](https://www.stocktitan.net/sec-filings/BBD/6-k-a-bank-bradesco-amended-current-report-foreign-issuer-0d4a2a783043.html) - Bradesco’s 2025 IFRS results show net income of R$23.9B, higher EPS, 11% loan portfolio growth, 12.2...

8. [Banco Bradesco posts R$6.5B Q4 2025 profit | BBD SEC ...](https://www.stocktitan.net/sec-filings/BBD/6-k-bank-bradesco-current-report-foreign-issuer-23ff1c465be7.html) - Banco Bradesco’s 4Q25 profit hit R$6.5B as 2025 recurring net income rose 26.1% to R$24.7B, supporte...

9. [BBDC4 Q4-2025 Earnings Call - Alpha Spread](https://www.alphaspread.com/security/bovespa/bbdc4/investor-relations/earnings-call/q4-2025) - Banco Bradesco SA (BOVESPA:BBDC4) Q4-2025 earnings call transcript.

10. [Economic and Financial Analysis Report](https://filemanager-cdn.mziq.com/published/80f2e993-0a30-421a-9470-a4d5c8ad5e9f/a5c11cdf-583b-4fca-b3a4-2eb68a9b3652_bradesco_4q25_economic_and_financial_analysis_report.pdf)

11. [At Bradesco, the technology agenda is advancing "step by step".](https://neofeed.com.br/negocios/no-bradesco-a-agenda-tecnologica-avanca-step-by-step/en/) - Bradesco is accelerating its technology agenda, scaling the use of AI, and seeking efficiency gains ...

12. [Banco Bradesco Q4 Earnings Call Highlights](https://finance.yahoo.com/news/banco-bradesco-q4-earnings-call-223340077.html) - Banco Bradesco (NYSE:BBD) reported recurring net income of BRL 6.5 billion for the fourth quarter of...

13. [Banco Bradesco S A : Transcription - Portuguese Conference Call ...](https://www.marketscreener.com/news/banco-bradesco-s-a-transcription-portuguese-conference-call-translated-into-english-1877f8-orig-ce7f5bd9dd89f725) - Marcelo Noronha - Good morning everyone! I'm Marcelo Noronha. I'm over here in Cidade de Deus, at Br...

14. [Bradesco deve concluir a reincorporação do Next na ...](https://www.folhavitoria.com.br/economia/bradesco-deve-concluir-a-reincorporacao-do-next-na-virada-do-ano/) - O Bradesco deve concluir a reincorporação do Next na virada do ano. De acordo com o presidente do ba...

15. [Bradesco opta pela multicloud, mas afasta 100% nuvem ...](https://convergenciadigital.com.br/especial/cloud/bradesco-opta-pela-multicloud-mas-afasta-100-nuvem-no-curto-prazo/) - O Bradesco optou pelo multicloud e diz que as visões diferentes dos fornecedores são 'vitais' para i

16. [next: Conta Digital e Cartão – Apps on ...](https://play.google.com/store/apps/details?id=br.com.bradesco.next&hl=en_IN) - next has a complete account for you: it is 100% digital, with a card with no annual fees and everyth...

17. [Credicorp 2025 profit jumps, ROE hits 19% | BAP SEC Filing](https://www.stocktitan.net/sec-filings/BAP/6-k-credicorp-ltd-current-report-foreign-issuer-708fd4055a43.html) - ROE reached 19.0%. full-year net income rose 25.9% to S/6,925.4 million, driving a 2025 ROE of 19.0%...

18. [Com IA generativa, BIA já retém até 90% das demandas ... - TI Inside](https://tiinside.com.br/11/06/2025/com-ia-generativa-bia-ja-retem-ate-90-das-demandas-no-atendimento-digital-do-bradesco/)

19. [Bradesco alcança +80% de resolutividade com IA ...](https://www.microsoft.com/pt-br/customers/story/18828-banco-bradesco-azure-ai-services)

20. [With generative AI, BIA already retains up to 90% of demands in ...](https://tiinside.com.br/en/11/06/2025/com-ia-generativa-bia-ja-retem-ate-90-das-demandas-no-atendimento-digital-do-bradesco/)

21. [Possible 2025: The Trusted AI and Data Conference | Teradata](https://www.teradata.fr/events/possible/sessions/banco-bradesco?topics=googlecloud&topics=technology&industries=financial-services&industries=media-ent) - Dive into breakout sessions, dynamic keynotes, and interactive roundtables at Possible, the Trusted ...

22. [Bradesco lança espaço de inovação que reúne startups e grandes ...](https://g1.globo.com/economia/noticia/bradesco-lanca-espaco-de-inovacao-que-reune-startups-e-grandes-empresas-veja-video.ghtml) - inovaBra habitat fica em São Paulo e foi criado para incentivar desenvolvimento de novas tecnologias...

23. [para startups - inovabra | Bradesco](https://www.inovabra.com.br/inovabra/startups)

24. [Inovabra Habitat fecha parceria com Acate e amplia ecossistema de startups - ABES](https://abes.com.br/inovabra-habitat-fecha-parceria-com-acate-e-amplia-ecossistema-de-startups/) - Compartilhe O Inovabra Habitat, espaço de coinovação do Bradesco, anunciou nesta semana uma nova par...

25. [Ecossistema de coinovação do Bradesco completa um ano superando metas](https://oglobo.globo.com/economia/inovacao/ecossistema-de-coinovacao-do-bradesco-completa-um-ano-superando-metas-23555022) - Com 190 startups, 70 corporações e eventos, inovabra habitat desponta como espaço efetivo em inovaçã...

26. [Ecossistema colaborativo impulsiona inovação em São Paulo](https://oglobo.globo.com/economia/inovacao/ecossistema-colaborativo-impulsiona-inovacao-em-sao-paulo-22944419) - Comandado pelo banco Bradesco, inovaBra habitat reinventa a forma de fazer negócios

27. [Credicorp (BAP) Investor Update Summary | Quartr](https://quartr.com/events/credicorp-bap-investor-update_Fk4R6ZG1) - Summary of Credicorp (BAP) Investor Update, combining transcript, slides, and related documents.

28. [BCP da un paso hacia el Open Banking con el despliegue ...](https://revistaganamas.com.pe/bcp-da-un-paso-hacia-el-open-banking-con-el-despliegue-de-sus-apis-para-fintechs/)

